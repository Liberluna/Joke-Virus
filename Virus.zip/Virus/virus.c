#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){

    const char *foldertname = "doc";
    char command[256];
    snprintf(command, sizeof(command),"mkdir %s", foldertname);
    system(command);

    printf("不明なエラーが発生しました。\n");

    for(int i = 0; i < 100; i++){
        char filePath[256];
        snprintf(filePath, sizeof(filePath), "%s/file%d.txt", foldertname, i);
        FILE *file = fopen(filePath, "w");
        if(file) fclose(file);
    }

    return 0;
}